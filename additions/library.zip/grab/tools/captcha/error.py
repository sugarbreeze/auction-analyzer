class CaptchaError(Exception):
    pass
